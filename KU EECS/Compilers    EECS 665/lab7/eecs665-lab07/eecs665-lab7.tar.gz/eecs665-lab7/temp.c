int a, y;
int int_glob;
double d_glob;

main()
{
  int loc1, loc2;
  double d_arr[10], d_loc;
  d_arr[0] = 3;

  loc1 = 0;
  if(loc1 == 10){
    int b_loc1;
    double bd_loc2;
  }
}

test01(int x, float z)
{
  int x, y;
  if (x && y){
    int s, p, x;
    s = p = x = 0;
  }
  {
    float t, u, s;
  }
  return 1;
}

test02(int m, int n)
{
  int m, y;
  if (n && y){
    int m, p, s;
    s = p = m = 0;
  }
  {
    double t, u, s;
  }
  return 1;
}
