EECS672_Proj2
=============

Project 2: simple Chess Board

TODO:
	+add curved surfaces
	     +sphere for top of pawn
	+queen
	+knight
	+rook
	+bishop
	+more points on squares so that angled view won't make squares looked jagged
