/*----------------------------
 * Animal.java
 * Warren Scipio
 * EECS - 168 Lab 7
 * sends methods to TestOldMacDonald
 * 10/16/2012
 */

public class Animal {
	
	String type;
	String sound;
	
	public String getType( ){
		
		return type;
	}
	
	public void setType(String newType){
		type = newType;
	}
	
	public String getSound(){
		
		return sound;
		
	}
	
	public void setSound(String newSound){
		sound = newSound;
		
	}
	
}

