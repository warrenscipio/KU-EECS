/*---------------------------------------------------------------
*
* CircleArea.java
* Warren Scipio w538s936@ku.edu
* EECS-168 Lab 2
* gives area of circle with a radius 20
*
* 08/28/12
*
------------------------------------------------------------------*/



public class CircleArea{

	public static void main(String[] args){

		final double PI = 3.141592;
		double radius;
		double area;

		radius = 20;
		area = radius * PI;
		System.out.println("The area for the circle of radius " + radius + " is " + area);

	}
}		
