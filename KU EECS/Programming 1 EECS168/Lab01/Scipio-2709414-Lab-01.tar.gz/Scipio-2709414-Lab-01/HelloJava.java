public class HelloJava{

        public static void main(String[] args){
               System.out.println("Hello Java!");
               System.out.println("This is going to be a fun lab!!");
        }
}
