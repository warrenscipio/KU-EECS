#include "executive.h" //defines class
#include <string>

using namespace std;


int main(int argc, char* argv[])
{
 
  executive e(argv[1], argv[2]);
  
  return 0;
}
