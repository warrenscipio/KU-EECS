/**
@Filename main.cpp
@Author Warren Scipio
*/

#include "Executive.h" 
#include <string>
#include <iostream>

using namespace std;


int main(int argc, char* argv[])
{
	
	Executive e(argv[1], argv[2], argv[3], argv[4]);
  
  return 0;
}
